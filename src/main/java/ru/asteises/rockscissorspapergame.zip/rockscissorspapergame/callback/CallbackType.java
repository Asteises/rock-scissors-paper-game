package ru.asteises.rockscissorspapergame.callback;

public enum CallbackType {
    CITY_CHOOSE,
    TYPE_CHOOSE,

    ADDRESS_CHOOSE,

    PIN_OK,
    PIN_WRONG,

    PIN_ADD,
    PIN_DONT_ADD
}
