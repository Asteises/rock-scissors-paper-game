package ru.asteises.rockscissorspapergame;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RockScissorsPaperGameApplication {

	public static void main(String[] args) {
		SpringApplication.run(RockScissorsPaperGameApplication.class, args);
	}

}
