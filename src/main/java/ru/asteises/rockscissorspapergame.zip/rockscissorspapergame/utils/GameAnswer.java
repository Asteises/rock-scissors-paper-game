package ru.asteises.rockscissorspapergame.utils;

public enum GameAnswer {

    ROCK("ROCK"),
    SCISSORS("SCISSORS"),
    PAPER("PAPER"),

    YES("YES"),
    NO("NO");

    public final String name;

    GameAnswer(String name) {
        this.name = name;
    }

    public static GameAnswer valueOfName(String name) {
        for (GameAnswer answer : values()) {
            if (answer.name.equals(name)) {
                return answer;
            }
        }
        return null;
    }
}
